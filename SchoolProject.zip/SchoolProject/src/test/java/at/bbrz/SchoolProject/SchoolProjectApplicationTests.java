package at.bbrz.SchoolProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
